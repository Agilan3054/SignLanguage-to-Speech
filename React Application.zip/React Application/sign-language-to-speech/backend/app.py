import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.utils import to_categorical
import matplotlib.pyplot as plt
import os
from flask import Flask, request, jsonify, send_file
from gtts import gTTS
import cv2

app = Flask(__name__)

# Load and preprocess data
def load_data():
    train_df = pd.read_csv('sign_mnist_train.csv')
    test_df = pd.read_csv('sign_mnist_test.csv')

    X_train = train_df.drop(columns=['label']).values
    y_train = train_df['label'].values
    X_test = test_df.drop(columns=['label']).values
    y_test = test_df['label'].values

    unique_labels = np.unique(np.concatenate((y_train, y_test)))
    label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
    y_train = np.array([label_mapping[label] for label in y_train])
    y_test = np.array([label_mapping[label] for label in y_test])

    image_size = 28
    X_train = X_train.reshape(-1, image_size, image_size, 1) / 255.0
    X_test = X_test.reshape(-1, image_size, image_size, 1) / 255.0

    y_train = to_categorical(y_train, len(unique_labels))
    y_test = to_categorical(y_test, len(unique_labels))

    return X_train, y_train, X_test, y_test, unique_labels

# Build the model
def build_model(input_shape, num_classes):
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dense(num_classes, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# Generate audio file
def text_to_speech(text, filename='audio/output.mp3'):
    tts = gTTS(text=text, lang='en')
    tts.save(filename)
    return filename

# Preprocess an input image
def preprocess_image(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise ValueError("Image not found or unable to open.")
    image = cv2.resize(image, (28, 28))
    image = image.reshape(1, 28, 28, 1) / 255.0
    return image

@app.route('/predict', methods=['POST'])
def predict():
    image_path = request.json['image_path']
    model = tf.keras.models.load_model('sign_language_model.h5')  # Load your trained model

    # Predict the label
    image = preprocess_image(image_path)
    prediction = model.predict(image)
    predicted_label = np.argmax(prediction)

    # Convert predicted label to text
    label_mapping = {
        0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E',
        5: 'F', 6: 'G', 7: 'H', 8: 'I', 9: 'J',
        10: 'K', 11: 'L', 12: 'M', 13: 'N', 14: 'O',
        15: 'P', 16: 'Q', 17: 'R', 18: 'S', 19: 'T',
        20: 'U', 21: 'V', 22: 'W', 23: 'X', 24: 'Y', 25: 'Z'
    }
    predicted_alphabet = label_mapping.get(predicted_label, 'Unknown')

    # Generate audio file
    audio_file = text_to_speech(predicted_alphabet)

    return jsonify({'predicted_word': predicted_alphabet, 'audio_file': audio_file})

@app.route('/audio/<filename>', methods=['GET'])
def get_audio(filename):
    return send_file(os.path.join('audio', filename), as_attachment=True)

if __name__ == '__main__':
    if not os.path.exists('audio'):
        os.makedirs('audio')
    X_train, y_train, X_test, y_test, unique_labels = load_data()
    model = build_model((28, 28, 1), len(unique_labels))
    model.fit(X_train, y_train, epochs=4, validation_data=(X_test, y_test))
    model.save('sign_language_model.h5')
    app.run(debug=True)
