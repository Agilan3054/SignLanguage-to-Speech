import React from 'react';

const ResultDisplay = ({ result }) => {
    return (
        <div>
            <h2>Predicted Gesture: {result}</h2>
            <audio controls src={`/${result}.mp3`} />
        </div>
    );
};

export default ResultDisplay;
