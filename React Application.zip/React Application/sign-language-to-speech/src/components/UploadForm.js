import React, { useState } from 'react';
import axios from 'axios';
import { Button, TextField } from '@mui/material';

const UploadForm = ({ onPrediction }) => {
    const [selectedImage, setSelectedImage] = useState(null);
    const [loading, setLoading] = useState(false);

    const handleImageChange = (e) => {
        setSelectedImage(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!selectedImage) return;

        const formData = new FormData();
        formData.append('image', selectedImage);

        setLoading(true);
        try {
            const response = await axios.post('http://localhost:5000/predict', formData);
            onPrediction(response.data);
        } catch (error) {
            console.error('Error uploading image:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="file" accept="image/*" onChange={handleImageChange} />
            <Button type="submit" variant="contained" disabled={loading}>
                {loading ? 'Loading...' : 'Predict'}
            </Button>
        </form>
    );
};

export default UploadForm;
