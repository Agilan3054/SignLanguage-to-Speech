import React, { useState } from 'react';
import './App.css'; // Import the CSS file

const App = () => {
    const [predictedWord, setPredictedWord] = useState('');
    const [audioFile, setAudioFile] = useState('');
    const [imageFile, setImageFile] = useState(null);

    const handleImageChange = (e) => {
        setImageFile(e.target.files[0]); // Save the uploaded image
    };

    const handlePredict = async () => {
        const formData = new FormData();
        formData.append('image', imageFile); // Append the image file to FormData

        const response = await fetch('/predict', {
            method: 'POST',
            body: formData, // Send FormData with the request
        });

        const data = await response.json();
        setPredictedWord(data.predicted_word);
        setAudioFile(data.audio_file);
    };

    return (
        <div className="app-container">
            <h1>Sign Language Recognition</h1>
            <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="file-input"
            />
            <button onClick={handlePredict} className="predict-button">
                Predict
            </button>
            {predictedWord && <h2>Predicted Word: {predictedWord}</h2>}
            {audioFile && (
                <audio controls className="audio-player">
                    <source src={audioFile} type="audio/mpeg" />
                    Your browser does not support the audio element.
                </audio>
            )}
        </div>
    );
};

export default App;

